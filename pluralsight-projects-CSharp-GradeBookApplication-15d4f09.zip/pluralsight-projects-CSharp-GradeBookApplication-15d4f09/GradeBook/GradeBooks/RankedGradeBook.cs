﻿using System;

namespace GradeBook.GradeBooks
{
    public class RankedGradeBook : BaseGradeBook
    {
        public RankedGradeBook(string name) : base(name)
        {
            Type = Enums.GradeBookType.Ranked;
        }

        public override char GetLetterGrade(double averageGrade)
        {
            var count = 0;
            foreach (var student in Students)
            {
                count++;
            }
            if (count < 5)
            {
                throw new InvalidOperationException("Ranked-grading requires a minimum of 5 students to work");
            }
            if (averageGrade >= 80)
            {
                return 'A';
            }
            if (averageGrade >= 60)
            {
                return 'B';
            }
            if (averageGrade >= 40)
            {
                return 'C';
            }
            if (averageGrade >= 20)
            {
                return 'D';
            }
            return 'F';
        }

        public override void CalculateStatistics()
        {
            var count = 0;
            foreach (var student in Students)
            {
                count++;
            }
            if (count < 5)
            {
                Console.WriteLine("Ranked grading requires at least 5 students with grades in order to properly calculate a student's overall grade.");
                return;
            }
            base.CalculateStatistics();
        }

        public override void CalculateStudentStatistics(string name)
        {
            var count = 0;
            foreach (var student in Students)
            {
                count++;
            }
            if (count < 5)
            {
                Console.WriteLine("Ranked grading requires at least 5 students with grades in order to properly calculate a student's overall grade.");
                return;
            }
            base.CalculateStudentStatistics(name);
        }
    }
}
